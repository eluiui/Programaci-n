package ricksy.business;

interface GuestDispatcher {

    void dispatch(CreditCard card);

}