package domain.bicicleta;

public interface Movil {

    int getId();
    
}
