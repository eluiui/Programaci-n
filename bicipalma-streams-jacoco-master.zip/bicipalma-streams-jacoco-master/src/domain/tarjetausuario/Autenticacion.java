package domain.tarjetausuario;

public interface Autenticacion {

    boolean isActivada();
    
}
